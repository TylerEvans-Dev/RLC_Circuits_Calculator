#ifndef Criticallydamped_hpp
#define Criticallydamped_hpp
#include <iostream>
using namespace std;

void functionCritDampedSeries(double Rth, double L, double C,double alpha, double omega);

void functionCritDampedPar(double Rth, double L, double C, double alpha, double omega);

#endif /* Criticallydamped_hpp */
